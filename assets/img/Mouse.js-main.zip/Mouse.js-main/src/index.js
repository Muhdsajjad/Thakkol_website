import './main.scss';
import Mouse from './js/mouse';

window.Mouse = Mouse