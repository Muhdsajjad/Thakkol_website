import './main.scss';
import Mouse from './js/mouse';

export {Mouse}